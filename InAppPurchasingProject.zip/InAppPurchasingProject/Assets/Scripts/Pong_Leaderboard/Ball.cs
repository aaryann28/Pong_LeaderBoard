using System.Collections;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public float speed = 5.0f;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        LaunchBall();
    }

    void LaunchBall()
    {

        transform.position = Vector3.zero;
        float x = Random.Range(0, 2) == 0 ? -1 : 1;
        float y = Random.Range(-1.0f, 1.0f);
        Vector2 direction = new Vector2(x, 0).normalized;
        rb.velocity = direction * speed;
    }

    //void OnCollisionEnter2D(Collision2D collision)
    //{
    //    if (collision.gameObject.CompareTag("Paddle"))
    //    {
    //        //float y = Random.Range(-1.0f, 1.0f);
    //        //Vector2 direction = new Vector2(rb.velocity.x, y).normalized;
    //        //rb.velocity = direction * speed;

    //        Vector2 normal = collision.GetContact(0).normal;
    //        rb.velocity = Vector2.Reflect(rb.velocity, normal) * speed;

    //    }
    //    else
    //    {
    //        // Reflect the ball's velocity for other collisions (e.g., boundaries)
    //        Vector2 normal = collision.GetContact(0).normal;
    //        rb.velocity = Vector2.Reflect(rb.velocity, normal) * speed;
    //    }
    //}


    private void OnCollisionEnter2D(Collision2D collision)
    {
        

        //GetComponent<AudioSource>().Play();


        
        if (collision.gameObject.tag =="Player")
        {
            wayBall(collision, 1);
            ScoreManager.instance.IncreaseScore();
        }
        if (collision.gameObject.tag == "AI")
        {
            wayBall(collision, -1);
        }
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "PlayerZone")
        {
            StartCoroutine("restBall", 1f);
        }
        if (collision.gameObject.tag == "AIZone")
        {
            StartCoroutine("restBall", -1f);
        }
    }


    IEnumerator restBall(float x) // 1 for right
    {
        yield return new WaitForSeconds(1);
        //transform.position = Vector3.zero;
        //Vector2 direction = new Vector2(x, 0).normalized;


        GameOver();
    }

    void GameOver()
    {
        ScoreManager.instance.GameOver();
    }


    private void wayBall(Collision2D collision, int x)
    {
        float a = transform.position.y - collision.gameObject.transform.position.y;
        float b = collision.collider.bounds.size.y;
        float y = a / b;
        rb.velocity = new Vector2(x, y) * speed;
    }


}
