using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
   
    public static ScoreManager instance;

    public TMP_Text scoreDispTxt;
    public GameObject gameOverPannel;
    public int PlayerScore;
    public int hitScore;


    private void Awake()
    {
        instance = this;
    }

    public void IncreaseScore()
    {
        PlayerScore += hitScore;
        scoreDispTxt.text = "Score: " + PlayerScore;
    }

    public void GameOver()
    {
        gameOverPannel.SetActive(true);
    }

}
