using UnityEngine;
using System.IO;
using System.Collections.Generic;
using TMPro;
using UnityEngine.SocialPlatforms.Impl;

public class PlayerDataManager : MonoBehaviour
{
    [System.Serializable]
    public class Player
    {
        public string name;
        public int score;
    }

    [System.Serializable]
    public class PlayerList
    {
        public List<Player> players = new List<Player>();
    }

    private PlayerList playerList = new PlayerList();
    private string filePath;

    public TMP_InputField nameInput;
    public TMP_Text allPlayerScoreDisp;


    private void Start()
    {
        filePath = Path.Combine(Application.persistentDataPath, "players.json");
        string json = File.ReadAllText(filePath);
        playerList = JsonUtility.FromJson<PlayerList>(json);

    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            SavePlayerData("PlayerName"+Random.Range(0,10), Random.Range(0, 100));
        }

        if (Input.GetKeyDown(KeyCode.Tab))
        {
            LoadPlayerData();
        }
    }


    public void onSubmitScoreBtnClick(TMP_InputField nameInp)
    {
        Player newPlayer = new Player { name = nameInp.text, score = ScoreManager.instance.PlayerScore };
        playerList.players.Add(newPlayer);

        string json = JsonUtility.ToJson(playerList, true);
        File.WriteAllText(filePath, json);
        DisplayLoadPlayerData();
    }

    private void SavePlayerData(string name, int score)
    {
        Player newPlayer = new Player { name = name, score = score };
        playerList.players.Add(newPlayer);

        string json = JsonUtility.ToJson(playerList, true);
        File.WriteAllText(filePath, json);
    }

    private void LoadPlayerData()
    {
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            playerList = JsonUtility.FromJson<PlayerList>(json);

            // Sort the players by score in descending order
            playerList.players.Sort((x, y) => y.score.CompareTo(x.score));

            foreach (Player player in playerList.players)
            {
                Debug.Log("Name: " + player.name + ", Score: " + player.score);
            }
        }
        else
        {
            Debug.Log("No data found.");
        }
    }

    private void DisplayLoadPlayerData()
    {
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            playerList = JsonUtility.FromJson<PlayerList>(json);

            // Sort the players by score in descending order
            playerList.players.Sort((x, y) => y.score.CompareTo(x.score));

            foreach (Player player in playerList.players)
            {
                Debug.Log("Name: " + player.name + ", Score: " + player.score);
                allPlayerScoreDisp.text += player.name + "               " + player.score + "\n";
            }
        }
        else
        {
            Debug.Log("No data found.");
        }
    }

}
